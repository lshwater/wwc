<?php
App::uses('AppModel', 'Model');
/**
 * Queue Model
 *
 */
class Eventarrangementtype extends AppModel {

    public $hasMany = array(
        'Eventarrangement' => array(
            'className' => 'Eventarrangement',
            'foreignKey' => 'eventarrangementtype_id',
            'dependent' => true,
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'exclusive' => '',
            'finderQuery' => '',
            'counterQuery' => ''
        ),
    );
}
