<?php
App::uses('AppModel', 'Model');

class Activitytype extends AppModel {

}
