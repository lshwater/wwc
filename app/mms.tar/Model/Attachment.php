<?php
App::uses('AppModel', 'Model');

class Attachment extends AppModel {
    public $belongsTo = array(
        'User'=> array(
            'className' => 'User',
            'foreignKey' => 'user_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        ),
    );
}
