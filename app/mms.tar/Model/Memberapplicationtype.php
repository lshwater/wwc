<?php
App::uses('AppModel', 'Model');


class Memberapplicationtype extends AppModel {

}
