<?php
App::uses('AppModel', 'Model');

class Financialitem extends AppModel {

    public $hasMany = array(
        'Financialbudgetdetail' => array(
            'className' => 'Financialbudgetdetail'
        )
    );

}
