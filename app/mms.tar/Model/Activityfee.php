<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 * @property Unit $Unit
 */
class Activityfee extends AppModel {

    public $belongsTo = array(
        'Activity' => array(
            'className' => 'Activity',
            'foreignKey' => 'activity_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        ),
        "Membertype"=> array(
            'className' => 'Membertype',
            'foreignKey' => 'membertype_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        ),
    );


}
