<?php
App::uses('AppModel', 'Model');

class Activitygroup extends AppModel {


}
