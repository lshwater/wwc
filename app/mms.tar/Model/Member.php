<?php
App::uses('AppModel', 'Model');
App::uses('SimplePasswordHasher', 'Controller/Component/Auth');
/**
 * Member Model
 *
 * @property Memberinputfield $Memberinputfield
 * @property Membertype $Membertype
 */
class Member extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(
        'code' => array(
            'notEmpty' => array(
                'rule' => array('notEmpty'),
                'message' => 'This field cannot be empty',
                //'allowEmpty' => false,
                //'required' => false,
                //'last' => false, // Stop validation after this rule
                //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
            'unique' => array(
                'rule' => 'isUnique',
                'required' => 'create',
                'message' => 'Value already exist',
            ),
            'pattern'=>array(
                'rule'      => '/^[a-zA-Z0-9\w?!\.;:,@#$%^&*\/\[\]\(\)=\+-]*$/',
                'message'   => 'Only alphenumeric allowed',
            ),
        ),
        'membercard' => array(
            'unique' => array(
                'rule' => 'isUnique',
                'required' => 'create',
                'message' => 'Value already exist',
                'allowEmpty' => true,
            ),
        ),
		'active' => array(
			'boolean' => array(
				'rule' => array('boolean'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
        'identity' => array(
            'notempty' => array(
                'rule' => array('notempty'),
                'message' => '不能留空',
                //'allowEmpty' => false,
                //'required' => false,
                //'last' => false, // Stop validation after this rule
                //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
            'unique' => array(
                'rule' => 'isUnique',
                'required' => 'create',
                'message' => '已經存在'
            ),
        ),
        'identityhash'=>array(
            'unique' => array(
                'rule' => 'isUnique',
                'required' => 'create',
                'message' => '已經存在'
            ),
        ),
        'membertype_id' => array(
            'numeric' => array(
                'rule' => array('numeric'),
                //'message' => 'Your custom message here',
                //'allowEmpty' => false,
                //'required' => false,
                //'last' => false, // Stop validation after this rule
                //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
        )
	);

    public $belongsTo = array(
        'Membertype' => array(
            'className' => 'Membertype',
            'foreignKey' => 'membertype_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        ),
        'Identitytype' => array(
            'className' => 'Identitytype',
            'foreignKey' => 'identitytype_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        ),
    );

	//The Associations below have been created with all possible keys, those that are not needed can be removed
    public $hasMany = array(
        'MemberCustomField' => array(
            'className' => 'MembersMemberinputfield',
            'dependent' => true
        ),
        "Parentmember"=> array(
            'className' => 'MembersMemberrelation',
            'foreignKey' => 'member_parent',
            'dependent' => true
        ),
        "Childmember"=> array(
            'className' => 'MembersMemberrelation',
            'foreignKey' => 'member_child',
            'dependent' => true
        ),
    );

    public $hasOne = array(
        'Volunteer' => array(
            'className' => 'Volunteer',
            'conditions' => "",
            'dependent' => true
        )
    );
/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
	public $hasAndBelongsToMany = array(
        'Eventproposaltarget' => array(
            'className' => 'Eventproposaltarget',
            'joinTable' => 'members_eventproposaltargets',
            'foreignKey' => 'member_id',
            'associationForeignKey' => 'eventproposaltarget_id',
            'unique' => 'keepExisting',
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'finderQuery' => '',
        ),
        'Memberapplication' => array(
            'className' => 'Memberapplication',
            'joinTable' => 'members_memberapplications',
            'foreignKey' => 'member_id',
            'associationForeignKey' => 'memberapplication_id',
            'unique' => 'keepExisting',
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'finderQuery' => '',
        ),
        'Activity'=> array(
            'className' => 'Activity',
            'joinTable' => 'activityapplicants',
            'foreignKey' => 'member_id',
            'associationForeignKey' => 'activity_id',
            'unique' => 'keepExisting',
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'finderQuery' => '',
        ),
	);

    public function beforeValidate($id = false, $table = null, $ds = null) {
        parent::__construct($id, $table, $ds);
        if (!empty($this->data[$this->alias]['identity'])) {
            $this->data[$this->alias]['identity'] = strtoupper(trim($this->data[$this->alias]['identity']));
            $this->data[$this->alias]['identityhash'] = $this->datahash($this->data[$this->alias]['identity']);
            $this->data[$this->alias]['identity'] = $this->encryptdata($this->data[$this->alias]['identity']);
        }
    }

    public function beforeSave($options = array()) {
//        debug($this->data);
//        debug("testing model");

        if (isset($this->data[$this->alias]['e_name_first'])) {
            $this->data[$this->alias]['e_name_first'] = trim($this->data[$this->alias]['e_name_first']);
            $this->data[$this->alias]['e_name_first'] = strtoupper($this->data[$this->alias]['e_name_first']);
        }
        if (isset($this->data[$this->alias]['e_name_last'])) {
            $this->data[$this->alias]['e_name_last'] = trim($this->data[$this->alias]['e_name_last']);
            $this->data[$this->alias]['e_name_last'] = strtoupper($this->data[$this->alias]['e_name_last']);
        }
        if (isset($this->data[$this->alias]['e_name_last']) && isset($this->data[$this->alias]['e_name_last'])) {
            $this->data[$this->alias]['e_name'] = $this->data[$this->alias]['e_name_last'].' '.$this->data[$this->alias]['e_name_first'];
        }

        if (isset($this->data[$this->alias]['c_name'])) {
            $this->data[$this->alias]['c_name'] = trim($this->data[$this->alias]['c_name']);
        }

        return true;
    }

    public function beforeFind($queryData) {

        if (isset($queryData['conditions'][$this->alias.'.e_name'])) {
            $queryData['conditions'][$this->alias.'.e_name'] = strtoupper($queryData['conditions'][$this->alias.'.e_name']);
        }

        if (isset($queryData['conditions'][$this->alias.'.e_name_first'])) {
            $queryData['conditions'][$this->alias.'.e_name_first'] = strtoupper($queryData['conditions'][$this->alias.'.e_name_first']);
        }

        if (isset($queryData['conditions'][$this->alias.'.e_name_last'])) {
            $queryData['conditions'][$this->alias.'.e_name_last'] = strtoupper($queryData['conditions'][$this->alias.'.e_name_last']);
        }

        if (isset($queryData['conditions'][$this->alias.'.c_name'])) {
            $queryData['conditions'][$this->alias.'.c_name'] = strtoupper($queryData['conditions'][$this->alias.'.c_name']);
        }

        return $queryData;
    }


    public function generatepassword($length = 8){
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $count = mb_strlen($chars);

        for ($i = 0, $result = ''; $i < $length; $i++) {
            $index = rand(0, $count - 1);
            $result .= mb_substr($chars, $index, 1);
        }

        return $result;
    }

    /*
     * Search Handler
     */
    public $actsAs = array('Search.Searchable');

    public $filterArgs = array(
        'filter' => array('type' => 'query', 'method' => 'orConditions'),
    );

    public function orConditions($data = array()) {

    }

    //HKID
    public function replace_identity(&$item2, $key){

        if($key == "identity"){
            $item2 = $this->decryptdata($item2);
        }

    }

    public function afterFind($results, $primary = false) {
        foreach ($results as $key => $val) {
            if (isset($val[$this->alias]['dob'])) {
                $results[$key][$this->alias]['age'] = date_diff(date_create($val[$this->alias]['dob']), date_create('today'))->y;;
            }
        }

        array_walk_recursive($results, array($this,'replace_identity'));

        return $results;
    }


    //checkmembership (date)
    public function checkmembership($id = null, $date = null, &$msg){
        if(!$this->exists($id)){
            $msg = "沒有此會員";
            return false;
        }
        if(!$date){
            $date = date("Y-m-d");
        }
        $rs = $this->find("count", array(
            "conditions"=>array(
                $this->alias.".valid"=>1,
                $this->alias.".active"=>1,
                $this->alias.".membershipdate >= "=>$date,
                $this->alias.".id"=>$id
            )
        ));
        if($rs == 0){
            $msg = "會籍不合資格，必須先續會到 {$date} 或以後日子。";
            return false;
        }

        return true;
    }

    public function deactiveapplication($id=null){
        if(!$this->exists($id)){
            return false;
        }

        $this->Behaviors->load('Containable');
        $options = array(
            'conditions' => array(
                'Member.' . $this->primaryKey => $id
            ),
            'contain' => array(
                'Memberapplication.id'
            ),
        );

        $member = $this->find('first', $options);
        if(empty($member)){
            return false;
        }
        foreach($member['Memberapplication'] as $application){

            $this->Memberapplication->id = $application['id'];
            if(!$this->Memberapplication->saveField('active', 0)){
                return false;
            }
        }

        return true;

    }

    public function constructvolunteer($member=null, $member_id=null){
//        debug($member);
        $volunteer = null;

        //id
        $volunteer['Volunteer']['member_id'] = $member_id;;
        //construct mandatory field
        $volunteer['Volunteer']['e_name'] = $member['Member']['e_name_last'].' '.$member['Member']['e_name_first'];
        $volunteer['Volunteer']['dob'] = $member['Member']['dob'];
        $volunteer['Volunteer']['gender'] = $this->retrievememberfield($member, 6);
        $volunteer['Volunteer']['phone_main'] = $this->retrievememberfield($member, 10);
        $volunteer['Volunteer']['identitytype_id'] = $member['Member']['identitytype_id'];
        $volunteer['Volunteer']['identity'] = $member['Member']['identity'];

        //construct optional field
        $volunteer['Volunteer']['c_name'] = $member['Member']['c_name'];
        $volunteer['Volunteer']['membercard'] = $member['Member']['membercard'];
        $volunteer['Volunteer']['phone_other'] = $this->retrievememberfield($member, 11);
        $volunteer['Volunteer']['address'] = $this->retrievememberfield($member, 8);
        $volunteer['Volunteer']['email'] = $this->retrievememberfield($member, 9);
        $volunteer['Volunteer']['education_level'] = $this->retrievememberfield($member, 15);

        //Eventproposaltarget
        $volunteer['Eventproposaltarget'] = $member['Eventproposaltarget'];
        $volunteer['Volunteertype'] = array(1);
        return $volunteer;
    }

    //retrieve member customer field by field_id
    public function retrievememberfield($member=null, $field_id=null){
        foreach($member['MemberCustomField'] as $field){
            if($field['memberinputfield_id'] == $field_id){
                return $field['value'];
            }
        }
        return null;
    }

}
