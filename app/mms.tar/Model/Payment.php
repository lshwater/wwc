<?php
App::uses('AppModel', 'Model');

class Payment extends AppModel {

    public $hasMany = array(
        'Paymentitem' => array(
            'className' => 'Paymentitem',
            'foreignKey' => 'payment_id',
            'dependent' => true,
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'exclusive' => '',
            'finderQuery' => '',
            'counterQuery' => ''
        )
    );

}
