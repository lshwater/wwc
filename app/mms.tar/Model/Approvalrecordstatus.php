<?php
App::uses('AppModel', 'Model');
/**
 * Queue Model
 *
 */
class Approvalrecordstatus extends AppModel {

}
