<?php
App::uses('AppModel', 'Model');
/**
 * Menu Model
 *
 */
class Menu extends AppModel {

    /**
     * belongsTo associations
     *
     * @var array
     */
    public $belongsTo = array(
        'Menucategory' => array(
            'className' => 'Menucategory',
            'foreignKey' => 'menucategory_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        )
    );

/**
 * hasAndBelongsToMany associations
 *
 * @var array
 */
    public $hasAndBelongsToMany = array(
        'Group' => array(
            'className' => 'Group',
            'joinTable' => 'groups_menus',
            'foreignKey' => 'menu_id',
            'associationForeignKey' => 'group_id',
            'unique' => 'keepExisting',
            'conditions' => '',
            'fields' => '',
            'order' => '',
            'limit' => '',
            'offset' => '',
            'finderQuery' => '',
        ),
    );

    public function getmenu(){
        $group = CakeSession::read('Auth.groupsusers');
        $this->Behaviors->load('Containable');
        $menu = $this->find('all', array(
                'contain'=>array(
                    'Menucategory',
                    'Group'=>array(
                        'conditions'=>array(
                            "Group.id"=>$group
                        )
                    )
                ),
                'order'=>array(
                    'Menu.order ASC'
                )
            )
        );

        $return = array();
        if(!empty($menu)){
            foreach($menu as $val){
                if(!empty($val['Group'])){
                    $href = array(
                        'controller'=>$val['Menu']['controller'],
                        'action'=>$val['Menu']['action'],

                    );
                    if(!empty($val['Menu']['parameter'])){
                        $parm = explode(",",$val['Menu']['parameter']);
                        foreach($parm as $p){
                            $href[] =  $p;
                        }
                    }

                    $return['Menu'][$val['Menucategory']['id']][] = array(
                        'href'=>$href,
                        'name'=>$val['Menu']['name'],
                        'labelval'=>$val['Menu']['labelval'],
                        'labelclass'=>$val['Menu']['labelclass'],
                        'class'=>$val['Menu']['class']
                    );

                    $return['Menucategory'][$val['Menucategory']['id']] = $val['Menucategory'];
                }
            }
        }

        return $return;

    }
}
