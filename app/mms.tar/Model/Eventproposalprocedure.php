<?php
App::uses('AppModel', 'Model');
/**
 * Queue Model
 *
 */
class Eventproposalprocedure extends AppModel {

    public $belongsTo = array(
        'Eventproposal' => array(
            'className' => 'Eventproposal',
            'foreignKey' => 'eventproposal_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        )
    );

}
