<?php
App::uses('AppModel', 'Model');

class Membernextcode extends AppModel {

    public $belongsTo = array(
        'Year' => array(
            'className' => 'Year',
            'foreignKey' => 'year_id',
            'conditions' => '',
            'fields' => '',
            'order' => ''
        )
    );

    public function getnextcode(){
        $year = $this->Year->getcurrent();
        $membernextcode = $this->find('first', array(
           "conditions"=>array(
                $this->alias.".year_id"=>$year['Year']['id']
           )
        ));

        if(empty($membernextcode)){
            //create count
            $this->create();
            $this->save(array("year_id"=>$year['Year']['id'], "count"=>1));
            $membernextcode = $this->find("first", array("conditions"=>array(
                $this->alias.".year_id"=>$year['Year']['id'],
            )));
        }

        //format val=========
        $year_start = substr($year['Year']['start'], 2, 2);
        $year_end = substr($year['Year']['end'], 2, 2);
        $number = $membernextcode[$this->alias]['count'];

        $codeformat = null;
        $codeformat_raw = Configure::read("Member.code_format");
        eval("\$codeformat = $codeformat_raw;");

        if($this->updateAll(
            array('count' => "count+1"),
            array($this->alias.'.id' => $membernextcode[$this->alias]['id'])
        )){
            return configure::read("member_prefix").$codeformat.configure::read("member_suffix");
        }
        return false;
    }
}
