<?php
App::uses('AppModel', 'Model');


class Memberrelation extends AppModel {

//    public $hasMany = array(
//        'MembersMemberrelation' => array(
//            'className' => 'MembersMemberrelation',
//            'foreignKey' => 'relationship_id',
//        )
//    );
}
