<?php
App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');
/**
 * Members Controller
 *
 * @property Member $Member
 * @property PaginatorComponent $Paginator
 */
class MembersController extends AppController
{

    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator', 'Search.Prg');

    public function matching($activity_id = null)
    {
        $this->layout = "withoutmenu";
        if (!$this->Member->Activity->exists($activity_id)) {
            throw new NotFoundException(__('Invalid'));
        }

        $this->set('membertypes', $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1))));
        $this->set('eventproposaltargets', $this->Member->Eventproposaltarget->find('list', array('conditions' => array('active' => true))));

    }

    /**
     * index method
     *
     * @return void
     */
    public function index()
    {
        $this->Member->recursive = 0;
        $this->set('members', $this->Member->find('all'));
    }

    public function reissuecard($id = null)
    {
        $this->layout = "withoutmenu";

        if (!$this->Member->exists($id)) {
            throw new NotFoundException(__('Invalid member'));
        }

        if ($this->request->is(array('post', 'put'))) {
            $error = false;
            $this->Member->begin();
            if (!$this->Member->saveAssociated($this->request->data, array("deep" => true))) {
                $error = configure::read("error_prefix") . "00064";
            }

            if ($error) {
                $this->Member->rollback();
                $this->Session->setFlash(__('更新失敗，請再檢查後嘗試') . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));
            } else {
                $this->Member->commit();
                $this->Session->setFlash(__('更新成功'), 'default', array('class' => 'alert alert-success'));
                echo "<script>window.close();</script>";
            }
        } else {
            $options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
            $this->request->data = $this->Member->find('first', $options);
        }
    }

    /**
     * view method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function view($id = null)
    {
//        Configure::write('debug', 2);
        if (!$this->Member->exists($id)) {
            throw new NotFoundException(__('Invalid member'));
        }
        $this->Member->Behaviors->load('Containable');

        $options = array(
            'conditions' => array(
                'Member.' . $this->Member->primaryKey => $id,
            ),
            'contain' => array(
                "Membertype",
                "Identitytype",
                'MemberCustomField.Memberinputfield',
                'MemberCustomField.Memberinputfield.Inputtype',
                'MemberCustomField.Memberinputfield.Selectionlist',
                'MemberCustomField.Memberinputfield.Selectionlist.Selectionitem',
                "Eventproposaltarget",
                "Activity.Eventproposal",
                "Activity.Activityapplication"
            ),
        );
        $member = $this->Member->find('first', $options);
        $this->set('member', $member);
        $this->set("modal_title", $member['Member']['name']);

        $relationship = $this->Member->find('first', array(
            'conditions' => array(
                'Member.' . $this->Member->primaryKey => $id
            ),
            'contain' => array(
                'Parentmember.Parentmember',
                'Parentmember.Memberrelation',
                'Childmember.Childmember',
                'Childmember.Memberrelation'
            )
        ));

        foreach ($relationship['Parentmember'] as $key => $val) {
            $relationship['Parentmember'][$key]['Relatedmember'] = $val['Childmember'];
        }

        foreach ($relationship['Childmember'] as $key => $val) {
            $relationship['Childmember'][$key]['Relatedmember'] = $val['Parentmember'];
        }

        $this->set('relationship', array_merge($relationship['Parentmember'], $relationship['Childmember']));

    }

    public function newmembertype()
    {

        if ($this->request->is('post')) {
            if (!empty($this->request->data['Member']['mainmember_code'])) {
                $mainmember = $this->Member->find("first", array(
                    "conditions" => array(
                        $this->Member->alias . ".code" => $this->request->data['Member']['mainmember_code']
                    )
                ));
                if (!empty($mainmember)) {
                    $this->redirect(array('action' => 'newmemberfamily', $this->request->data['Member']['acc_no'], $mainmember['Member']['id']));
                } else {
                    $this->Session->setFlash(__('主申請人會員號碼不正確'), 'default', array('class' => 'alert alert-warning'));
                }
            } else {
                $this->redirect(array('action' => 'newmemberfamily', $this->request->data['Member']['acc_no']));
            }

        }
    }

    public function newmemberfamily($acc_no = null, $mainmember_id = null)
    {
        $this->Member->MemberCustomField->Memberinputfield->Behaviors->load('Containable');
        $customfields = $this->Member->MemberCustomField->Memberinputfield->find('all', array(
                'contain' => array(
                    'Inputtype' => array('fields' => array('htmltype', 'type')),
                    'Selectionlist',
                    'Selectionlist.Selectionitem'
                ),
                'order' => array('required' => 'DESC', 'order' => 'ASC')
            )
        );
        if (!empty($mainmember_id)) {
            $mainmember = $this->Member->find("first", array(
                "conditions" => array(
                    $this->Member->alias . ".id" => $mainmember_id
                )
            ));
            if (!empty($mainmember)) {
                $this->set('mainmember', $mainmember);
            } else {
                $this->Session->setFlash(__('主申請人會員號碼不存在'), 'default', array('class' => 'alert alert-warning'));
                $this->redirect(array('action' => 'newmembertype'));
            }
        }
        if ($this->request->is('post')) {
            $parent_id = '';
            $parent = '';
            $this->loadModel("Membernextcode");
            $this->Member->begin();
            $error = false;

            if(!empty($this->request->data['Mainmember'])){
                $parent = $this->request->data['Mainmember'];
            }else{
                $error = configure::read("error_prefix") . "00099";
            }

            if(!empty($this->request->data['Memberapplication']) && !$error){
                if (!$parent['isexistingmember']) {
                    //create and save the new Memberapplication FOR MAIN MEMBER ONLY
                    $this->request->data['Memberapplication']['mainmember_id'] = 0;
                    $this->request->data['Memberapplication']['code'] = uniqid();
                    $this->Member->Memberapplication->create();
                    if (!$this->Member->Memberapplication->save($this->request->data['Memberapplication'])) {
                        $error = configure::read("error_prefix") . "00017";
                    } else {
                        $app_code = configure::read("application_prefix") . str_pad($this->Member->Memberapplication->id, 8, 0, STR_PAD_LEFT) . configure::read("application_suffix");
                        if (!$this->Member->Memberapplication->saveField('code', $app_code)) {
                            $error = configure::read("error_prefix") . "00018";
                        }
                    }
                } //現有會員
                else {
                    $this->request->data['Memberapplication']['mainmember_id'] = $parent['Member']['id'];
                    $this->request->data['Memberapplication']['code'] = uniqid();
                    $this->request->data['Memberapplication']['Member'][] = $parent['Member']['id'];

                    $this->Member->Memberapplication->create();
                    if (!$this->Member->Memberapplication->save($this->request->data['Memberapplication'])) {
                        $error = configure::read("error_prefix") . "00017";
                    } else {
                        $app_code = configure::read("application_prefix") . str_pad($this->Member->Memberapplication->id, 8, 0, STR_PAD_LEFT) . configure::read("application_suffix");
                        if (!$this->Member->Memberapplication->saveField('code', $app_code)) {
                            $error = configure::read("error_prefix") . "00018";
                        }
                    }
                    $this->Member->id = $parent['Member']['id'];
                    $this->Member->saveField("last_memberapplication_id", $this->Member->Memberapplication->id);
                }
            }else{
                $error = configure::read("error_prefix") . "00001";
            }

            //MainMember
            if (!$parent['isexistingmember']) {
                $this->request->data['Member'][0] = $parent;
            }else{
                $this->Member->id = $parent_id = $parent['Member']['id'];
                $this->Member->saveField("active", 1);
                $this->Member->saveField("valid", 1);
                $this->Member->saveField("membershipdate", $this->request->data['Memberapplication']['enddate']);
                $this->Member->saveField("membertype_id", $this->request->data['Memberapplication']['membertype_id']);
                $this->Member->saveField("is_parent", 1);
            }

                //stanley=======
            foreach ($this->request->data['Member'] as $index => $member) {
                $isvolunteer = $member['isvolunteer'];

                if($index!=0){
                    $member['Childmember']['Childmember']['member_parent'] = $parent_id;
                }

                $member['Member']['code'] = uniqid();
                $member['Member']['membershipdate'] = $this->request->data['Memberapplication']['enddate'];
                $member['Member']['membertype_id'] = $this->request->data['Memberapplication']['membertype_id'];
                $member['Member']['last_memberapplication_id'] = $this->Member->Memberapplication->id;


                //reset Memberapplication array for saving the HABTM relationship
                $member['Memberapplication'] = '';
                $member['Memberapplication']['Memberapplication']['memberapplication_id'] = $this->Member->Memberapplication->id;

                $this->Member->create();

                if ($this->Member->saveAssociated($member, array("deep" => true))) {
                    if ($index == 0) {
                        $parent_id = $this->Member->id;
                        //update the Memberapplication mainmember_id
                        if (!$this->Member->Memberapplication->saveField('mainmember_id', $parent_id)) {
                            $error = configure::read("error_prefix") . "00005";
                        }
                    }

                    $code = $this->Membernextcode->getnextcode();

                    if (!$code || !$this->Member->saveField('code', $code)) {
                        $error = configure::read("error_prefix") . "00006";
                    }

                    if (!$this->Member->saveField('parent_id', $parent_id)) {
                        $error = configure::read("error_prefix") . "00007";
                    }

                } else {
                    $error = configure::read("error_prefix") . "00008";

                }

                if ($isvolunteer) {
                    if (!$this->Member->Volunteer->applyvolunteer($this->Member->constructvolunteer($member, $this->Member->id))) {
                        $error = configure::read("error_prefix") . "00046";
                    }
                }
            }

            if (!empty($this->request->data['ExistingMember'])) {
                //add existing member to the same application
                foreach ($this->request->data['ExistingMember'] as $index => $member) {

                    //update member fields
                    $member['Member']['membershipdate'] = $this->request->data['Memberapplication']['enddate'];
                    $member['Member']['parent_id'] = $parent_id;
                    $member['Member']['last_memberapplication_id'] = $this->Member->Memberapplication->id;
                    $member['Member']['valid'] = 1;
                    $member['Member']['active'] = 1;
                    $member['Member']['membertype_id'] = $this->request->data['Memberapplication']['membertype_id'];

                    if (!$this->Member->save($member['Member'])) {
                        $error = configure::read("error_prefix") . "00051";
                    }

                    if (!$this->Member->Parentmember->saverelation($parent_id, $member['Member']['id'], $member['Childmember']['Childmember']['relationship_id'])) {
                        $error = configure::read("error_prefix") . "00052";
                    }

                    //Add new Memberapplication relationship
                    $application = array(
                        'memberapplication_id' => $this->Member->Memberapplication->id,
                        'member_id' => $member['Member']['id']
                    );
                    $this->Member->MembersMemberapplication->create();
                    if (!$this->Member->MembersMemberapplication->save($application)) {
                        $error = configure::read("error_prefix") . "00067";
                    }

                    if ($isvolunteer) {
                        $this->Member->Behaviors->load('Containable');

                        $options = array(
                            'conditions' => array(
                                'Member.' . $this->Member->primaryKey => $member['Member']['id'],
                            ),
                            'contain' => array(
                                'MemberCustomField.Memberinputfield',
                                'MemberCustomField.Memberinputfield.Inputtype',
                                'MemberCustomField.Memberinputfield.Selectionlist',
                                'MemberCustomField.Memberinputfield.Selectionlist.Selectionitem',
                                "Eventproposaltarget"
                            ),
                        );

                        if (!$this->Member->Volunteer->applyvolunteer($this->Member->constructvolunteer($this->Member->find('first', $options), $member['Member']['id']))) {
                            $error = configure::read("error_prefix") . "00052";
                        }
                    }

                }
            }

            if ($error) {
                $this->Member->rollback();
                $this->Session->setFlash(__('資料出錯，請檢查') . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));
            } else {
                $this->Member->commit();
                $this->Session->setFlash(__('會員己成功登記'), 'default', array('class' => 'alert alert-success'));
                $this->redirect(array("controller" => "Memberapplications", "action" => "view", $this->Member->Memberapplication->id));
            }

        }

        $this->set(compact('customfields', 'units', 'levels'));
        $this->set('units', $this->Member->Memberapplication->Unit->find('list', array("conditions" => array($this->Member->Memberapplication->Unit->alias . ".active" => 1))));
        $this->set('identitytypes', $this->Member->Identitytype->find('list', array('conditions' => array('active' => true))));
        $this->set('membertypes', $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1))));
        $this->set('relationship', $this->Member->Parentmember->Memberrelation->find('list', array('conditions' => array('active' => true))));
        $this->set('eventproposaltargets', $this->Member->Eventproposaltarget->find('list', array('conditions' => array('active' => true))));
        $this->set('acc_no', $acc_no);
    }

    public function newmemberindividual()
    {
        $this->Member->MemberCustomField->Memberinputfield->Behaviors->load('Containable');
        $customfields = $this->Member->MemberCustomField->Memberinputfield->find('all', array(
                'contain' => array(
                    'Inputtype' => array('fields' => array('htmltype', 'type')),
                    'Selectionlist',
                    'Selectionlist.Selectionitem'
                ),
                'order' => array('required' => 'DESC', 'order' => 'ASC')
            )
        );

        if ($this->request->is('post')) {

            $error = false;

            $this->Member->begin();
            $this->Member->create();
            //cal the membershipdate
            $this->request->data['Member']['membershipdate'] = $this->request->data['Memberapplication']['enddate'];
            $this->request->data['Member']['membertype_id'] = $this->request->data['Memberapplication']['membertype_id'];
            $this->request->data['Member']['code'] = uniqid();

            //create and save the new Memberapplication
            $this->request->data['Memberapplication']['mainmember_id'] = 0;
            $this->request->data['Memberapplication']['code'] = uniqid();
            $this->Member->Memberapplication->create();
            if (!$this->Member->Memberapplication->save($this->request->data['Memberapplication'])) {
                $error = configure::read("error_prefix") . "00021";
            } else {
                $app_code = configure::read("application_prefix") . str_pad($this->Member->Memberapplication->id, 8, 0, STR_PAD_LEFT) . configure::read("application_suffix");
                if (!$this->Member->Memberapplication->saveField('code', $app_code)) {
                    $error = configure::read("error_prefix") . "00020";
                }
            }
            //Same last memberapplication
            $this->request->data['Member']['last_memberapplication_id'] = $this->Member->Memberapplication->id;

            //reset Memberapplication array for saving the HABTM relationship
            $this->request->data['Memberapplication'] = '';
            $this->request->data['Memberapplication']['Memberapplication']['memberapplication_id'] = $this->Member->Memberapplication->id;

            if ($this->Member->saveAll($this->request->data, array("deep" => true))) {
                //gen member code
//                Configure::write('debug', 2);
                $this->loadModel("Membernextcode");
                $code = $this->Membernextcode->getnextcode();

                if (!$code || !$this->Member->saveField('code', $code)) {
                    $error = configure::read("error_prefix") . "00001";
                }

                if (!$this->Member->saveField('parent_id', $this->Member->id)) {
                    $error = configure::read("error_prefix") . "00002";
                }
                //update the Memberapplication mainmember_id
                if (!$this->Member->Memberapplication->saveField('mainmember_id', $this->Member->id)) {
                    $error = configure::read("error_prefix") . "00003";
                }
            } else {
                $error = configure::read("error_prefix") . "00004";

            }

            if ($this->request->data['Member']['isvolunteer']) {
                if (!$this->Member->Volunteer->applyvolunteer($this->Member->constructvolunteer($this->request->data, $this->Member->id))) {
                    $error = configure::read("error_prefix") . "00047";
                }
            }

            if ($error) {
                $this->Member->rollback();
                $this->Session->setFlash(__('資料出錯，請檢查') . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));
            } else {
                $this->Member->commit();
                $this->Session->setFlash(__('會員己成功登記'), 'default', array('class' => 'alert alert-success'));
                $this->redirect(array("controller" => "Memberapplications", "action" => "view", $this->Member->Memberapplication->id));
            }
        }

        $this->set(compact('customfields', 'units', 'levels'));

        $this->set('identitytypes', $this->Member->Identitytype->find('list', array('conditions' => array('active' => true))));
        $this->set('units', $this->Member->Memberapplication->Unit->find('list', array("conditions" => array($this->Member->Memberapplication->Unit->alias . ".active" => 1))));
        $this->set('membertypes', $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1))));
        $this->set('relationship', $this->Member->Parentmember->Memberrelation->find('list', array('conditions' => array('active' => true))));
        $this->set('eventproposaltargets', $this->Member->Eventproposaltarget->find('list', array('conditions' => array('active' => true))));
    }

    public function editasnew($id = null)
    {

        $this->layout = "withoutmenu";
//        Configure::write('debug', 2);

        if (!$this->Member->exists($id)) {
            throw new NotFoundException(__('Invalid member'));
        }

        if ($this->request->is(array('post', 'put'))) {

            $error = false;

            $this->Member->begin();
            if ($this->Member->saveAssociated($this->request->data, array("deep" => true))) {

                if ($this->request->params['named']['redirect']) {
                    $redirecturl = urldecode($this->request->params['named']['redirect']);
                } else {
                    $redirecturl = array('action' => 'index');
                }

                if ($this->Member->Parentmember->deleteAll(array('Parentmember.member_parent' => $id), false)) {
                    foreach ($this->request->data['Parentmember'] as $relatedmember) {
                        if ($this->Member->Parentmember->create()) {
                            $error = configure::read("error_prefix") . "00058";
                        }
                        if (!$this->Member->Parentmember->save($relatedmember)) {
                            $error = configure::read("error_prefix") . "00059";
                        }
                    }
                } else {
                    $error = configure::read("error_prefix") . "00060";
                }
            } else {
                $error = configure::read("error_prefix") . "00061";
            }

            if ($error) {
                $this->Member->rollback();
                $this->Session->setFlash(__('更新失敗，請再檢查後嘗試') . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));

            } else {
                $this->Member->commit();
                $this->Session->setFlash(__('更新成功'), 'default', array('class' => 'alert alert-success'));
                echo "<script>window.close();</script>";
            }

        } else {
            $options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
            $this->request->data = $this->Member->find('first', $options);
            $this->request->data['MemberCustomField'] = Set::combine($this->request->data['MemberCustomField'], '{n}.memberinputfield_id', "{n}");

        }
        $this->Member->MemberCustomField->Memberinputfield->Behaviors->load('Containable');
        $memberinputfields = $this->Member->MemberCustomField->Memberinputfield->find('all', array(
                'contain' => array(
                    'Inputtype' => array('fields' => array('htmltype', 'type')),
                    'Selectionlist',
                    'Selectionlist.Selectionitem'
                ),
                'order' => array('required' => 'DESC', 'order' => 'ASC')
            )
        );
        $memberinputfields = Set::combine($memberinputfields, '{n}.Memberinputfield.id', "{n}");
        $membertypes = $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1)));
        $eventproposaltargets = $this->Member->Eventproposaltarget->find('list', array('conditions' => array('active' => true)));
        $this->set(compact('memberinputfields', 'membertypes', 'eventproposaltargets'));

        $this->Member->Behaviors->load('Containable');

        $relationship = $this->Member->find('first', array(
            'conditions' => array(
                'Member.' . $this->Member->primaryKey => $id
            ),
            'contain' => array(
                'Parentmember.Parentmember',
                'Parentmember.Memberrelation',
                'Childmember.Childmember',
                'Childmember.Memberrelation'
            )
        ));

        foreach ($relationship['Parentmember'] as $key => $val) {
            $relationship['Parentmember'][$key]['Relatedmember'] = $val['Childmember'];
        }

        foreach ($relationship['Childmember'] as $key => $val) {
            $relationship['Childmember'][$key]['Relatedmember'] = $val['Parentmember'];
        }

        $this->set('relationship', array_merge($relationship['Parentmember'], $relationship['Childmember']));
        $this->set('relations', $this->Member->Parentmember->Memberrelation->find('list', array('conditions' => array('active' => true))));
    }

    /**
     * edit method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function edit($id = null)
    {

        if (!$this->Member->exists($id)) {
            throw new NotFoundException(__('Invalid member'));
        }

        if ($this->request->is(array('post', 'put'))) {

            $error = false;

            $this->Member->begin();
            if ($this->Member->saveAssociated($this->request->data, array("deep" => true))) {

                if ($this->request->params['named']['redirect']) {
                    $redirecturl = urldecode($this->request->params['named']['redirect']);
                } else {
                    $redirecturl = array('action' => 'index');
                }

                if ($this->Member->Parentmember->deleteAll(array('Parentmember.member_parent' => $id), false)) {
                    foreach ($this->request->data['Parentmember'] as $relatedmember) {
                        if ($this->Member->Parentmember->create()) {
                            $error = configure::read("error_prefix") . "00058";
                        }
                        if (!$this->Member->Parentmember->save($relatedmember)) {
                            $error = configure::read("error_prefix") . "00059";
                        }
                    }
                } else {
                    $error = configure::read("error_prefix") . "00060";
                }
            } else {
                $error = configure::read("error_prefix") . "00061";
            }

            if ($error) {
                $this->Member->rollback();
                $this->Session->setFlash(__('更新失敗，請再檢查後嘗試') . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));

            } else {
                $this->Member->commit();
                $this->Session->setFlash(__('更新成功'), 'default', array('class' => 'alert alert-success'));
                $this->redirect($redirecturl);
            }

        } else {
            $options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
            $this->request->data = $this->Member->find('first', $options);
            $this->request->data['MemberCustomField'] = Set::combine($this->request->data['MemberCustomField'], '{n}.memberinputfield_id', "{n}");

        }
        $this->Member->MemberCustomField->Memberinputfield->Behaviors->load('Containable');
        $memberinputfields = $this->Member->MemberCustomField->Memberinputfield->find('all', array(
                'contain' => array(
                    'Inputtype' => array('fields' => array('htmltype', 'type')),
                    'Selectionlist',
                    'Selectionlist.Selectionitem'
                ),
                'order' => array('required' => 'DESC', 'order' => 'ASC')
            )
        );
        $memberinputfields = Set::combine($memberinputfields, '{n}.Memberinputfield.id', "{n}");
        $membertypes = $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1)));
        $eventproposaltargets = $this->Member->Eventproposaltarget->find('list', array('conditions' => array('active' => true)));
        $this->set(compact('memberinputfields', 'membertypes', 'eventproposaltargets'));

        $this->Member->Behaviors->load('Containable');

        $relationship = $this->Member->find('first', array(
            'conditions' => array(
                'Member.' . $this->Member->primaryKey => $id
            ),
            'contain' => array(
                'Parentmember.Parentmember',
                'Parentmember.Memberrelation',
                'Childmember.Childmember',
                'Childmember.Memberrelation'
            )
        ));

        foreach ($relationship['Parentmember'] as $key => $val) {
            $relationship['Parentmember'][$key]['Relatedmember'] = $val['Childmember'];
        }

        foreach ($relationship['Childmember'] as $key => $val) {
            $relationship['Childmember'][$key]['Relatedmember'] = $val['Parentmember'];
        }

        $this->set('relationship', array_merge($relationship['Parentmember'], $relationship['Childmember']));
        $this->set('relations', $this->Member->Parentmember->Memberrelation->find('list', array('conditions' => array('active' => true))));
    }

    public function advsearch()
    {
        $this->layout = "withoutmenu";
    }

    public function sendconfirmmail($id)
    {
        if (configure::read("member_username") == "email") {
            $this->autoRender = false;
            $this->Member->recursive = 0;
            $rs = $this->Member->find('first', array(
                    'conditions' => array(
                        'Member.id' => $id,
                        'Member.active' => 0
                    )
                )
            );
            if (!empty($rs)) {
                $hashstring = uniqid() . $this->Member->generatepassword(20);
                $this->Member->id = $rs['Member']['id'];
                if ($this->Member->saveField('hashstring', $hashstring)) {
                    $Email = new CakeEmail('default');
                    $Email->template('sendconfirmmail', 'membermail');
                    $Email->emailFormat('html');
                    $Email->subject("TESTING");
                    $Email->to($rs['Member']['username']);
                    $Email->helpers(array('Html'));
                    $Email->viewVars(array('hashstring' => $hashstring));
                    $Email->send();
                    echo "OK";
                }
            }
        }
    }

    public function extend()
    {
        $type = 'extendindividual';
        if ($this->request->is(array('post', 'put'))) {

            if ($this->request->data['Member']['type'] == "extendfamily") {
                $type = 'extendfamily';
            }

            $conditions = [];
            if($this->request->data['Member']['method'] == 'code' && !empty($this->request->data['Member']['membercode'])){
                $conditions['AND']['Member.code'] = $this->request->data['Member']['membercode'];
            }else if(!empty($this->request->data['Member']['membercard'])){
                $conditions['AND']['Member.membercard'] = $this->request->data['Member']['membercard'];
            }else{
                $this->Session->setFlash(__('必須輸入會員卡或會員編號'), 'default', array('class' => 'alert alert-danger'));
                $this->redirect(array("action" => "extend"));
            }

            $member = $this->Member->find("first",
                array("conditions" =>$conditions
                )
            );

            if (empty($member)) {
                $this->Session->setFlash(__('沒有此會員記錄'), 'default', array('class' => 'alert alert-danger'));
            } else {
                $membership_renew_days = configure::read("membership_renew_days");
                $caltime = strtotime("+" . $membership_renew_days . 'days');
                $beforetimesp = strtotime(date("Y-m-d", $caltime));
                if ($beforetimesp < strtotime($member['Member']['membershipdate'])) {
                    $this->Session->setFlash(__('會籍到期日是' . $member['Member']['membershipdate'] . "。還未能續期。"), 'default', array('class' => 'alert alert-danger'));
                } else {
                    $this->redirect(array("action" => $type, $member['Member']['id']));
                }
            }
        }
    }

    public function extendfamily($id = null)
    {

        $this->set('relations', $this->Member->Parentmember->Memberrelation->find('list', array('conditions' => array('active' => true))));

        $member = $this->Member->find("first",
            array("conditions" =>
            array(
                "Member.id" => $id
            )
            )
        );

        if (empty($member)) {
            $this->Session->setFlash(__('沒有此會員記錄'), 'default', array('class' => 'alert alert-danger'));
            $this->redirect(array("action" => "extend"));
        } else {

            $membership_renew_days = configure::read("membership_renew_days");
            $caltime = strtotime("+" . $membership_renew_days . 'days');
            $beforetimesp = strtotime(date("Y-m-d", $caltime));
            if ($beforetimesp < strtotime($member['Member']['membershipdate'])) {
                $this->Session->setFlash(__('會籍到期日是' . $member['Member']['membershipdate'] . "。還未能續期。"), 'default', array('class' => 'alert alert-danger'));
                $this->redirect(array("action" => "extend"));
            }
            //can renew
            $this->set("member", $member);
        }

        $this->set('membertypes', $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1))));
        $this->set('units', $this->Member->Memberapplication->Unit->find('list', array("conditions" => array($this->Member->Memberapplication->Unit->alias . ".active" => 1))));

        if ($this->request->is(array('post', 'put'))) {

            $error = false;
            $this->Member->begin();

            $this->Member->Memberapplication->create();
            $this->request->data['Memberapplication']['mainmember_id'] = $id;
            $this->request->data['Memberapplication']['code'] = uniqid();
            if ($this->Member->Memberapplication->save($this->request->data)) {
                $app_code = configure::read("application_prefix") . str_pad($this->Member->Memberapplication->id, 8, 0, STR_PAD_LEFT) . configure::read("application_suffix");
                if (!$this->Member->Memberapplication->saveField('code', $app_code)) {
                    $error = configure::read("error_prefix") . "00019";
                }

                foreach ($this->request->data['Member']['Member'] as $key => $member) {
                    if ($this->Member->exists($member)) {
                        $this->Member->id = $member;
                        if (!$this->Member->saveField('membershipdate', $this->request->data['Membership'][$key]['membershipdate'])) {
                            $error = configure::read("error_prefix") . "00009";
                        }
                        if (!$this->Member->saveField('active', '1')) {
                            $error = configure::read("error_prefix") . "00010";
                        }
                        if (!$this->Member->saveField('valid', '1')) {
                            $error = configure::read("error_prefix") . "00010";
                        }
                        if (!$this->Member->saveField('parent_id', $id)) {
                            $error = configure::read("error_prefix") . "00048";
                        }

                        if (!$this->Member->saveField('membertype_id', $this->request->data['Memberapplication']['membertype_id'])) {
                            $error = configure::read("error_prefix") . "00050";
                        }

                        if (!$this->Member->saveField('last_memberapplication_id', $this->Member->Memberapplication->id)) {
                            $error = configure::read("error_prefix") . "00065";
                        }


                        if(isset($this->request->data['Parentmember'][$key])){
                            if (!$this->Member->Parentmember->saverelation($this->request->data['Member']['Member'][0], $member, $this->request->data['Parentmember'][$key]['relationship_id'])) {
                                $error = configure::read("error_prefix") . "00052";
                            }
                        }

                    } else {
                        $error = configure::read("error_prefix") . "00011";
                    }

                }
            } else {
                $error = configure::read("error_prefix") . "00012";
            }

            if (!$error) {
                $this->Member->commit();
                $this->Session->setFlash(__("成功續期。"), 'default', array('class' => 'alert alert-success'));
                $this->redirect(array("controller" => "Memberapplications", "action" => "view", $this->Member->Memberapplication->id));
            } else {
                $this->Member->rollback();
                $this->Session->setFlash(__("續期不成功。") . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));
            }
        }
    }

    public function extendindividual($id = null)
    {

        $member = $this->Member->find("first",
            array("conditions" =>
                array(
                    "Member.id" => $id
                )
            )
        );
        if (empty($member)) {
            $this->Session->setFlash(__('沒有此會員記錄'), 'default', array('class' => 'alert alert-danger'));
            $this->redirect(array("action" => "extend"));
        } else {
            $membership_renew_days = configure::read("membership_renew_days");
            $caltime = strtotime("+" . $membership_renew_days . 'days');
            $beforetimesp = strtotime(date("Y-m-d", $caltime));
            if ($beforetimesp < strtotime($member['Member']['membershipdate'])) {
                $this->Session->setFlash(__('會籍到期日是' . $member['Member']['membershipdate'] . "。還未能續期。"), 'default', array('class' => 'alert alert-danger'));
                $this->redirect(array("action" => "extend"));
            } //can renew
            else {
                $this->set("member", $member);
            }
        }

        if ($this->request->is(array('post', 'put'))) {
//            Configure::write('debug', 2);
            $error = false;
            $this->Member->begin();

            $this->Member->Memberapplication->create();
            $this->request->data['Memberapplication']['mainmember_id'] = $member['Member']['id'];
            $this->request->data['Memberapplication']['code'] = uniqid();

            if ($this->Member->Memberapplication->save($this->request->data)) {

                $app_code = configure::read("application_prefix") . str_pad($this->Member->Memberapplication->id, 8, 0, STR_PAD_LEFT) . configure::read("application_suffix");
                if (!$this->Member->Memberapplication->saveField('code', $app_code)) {
                    $error = configure::read("error_prefix") . "00022";
                }

                $this->Member->id = $member['Member']['id'];
                if (!$this->Member->saveField('membershipdate', $this->request->data['Member']['membershipdate'])) {
                    $error = configure::read("error_prefix") . "00014";
                }
                if (!$this->Member->saveField('active', '1')) {
                    $error = configure::read("error_prefix") . "00015";
                }

                if (!$this->Member->saveField('valid', '1')) {
                    $error = configure::read("error_prefix") . "00015";
                }

                if (!$this->Member->saveField('parent_id', $id)) {
                    $error = configure::read("error_prefix") . "00049";
                }

                if (!$this->Member->saveField('membertype_id', $this->request->data['Memberapplication']['membertype_id'])) {
                    $error = configure::read("error_prefix") . "00050";
                }

                if (!$this->Member->saveField('last_memberapplication_id', $this->Member->Memberapplication->id)) {
                    $error = configure::read("error_prefix") . "00066";
                }

            }

            if (!$error) {
                $this->Member->commit();
                $this->Session->setFlash(__("成功續期。"), 'default', array('class' => 'alert alert-success'));
//                $this->redirect(array("action"=>"view", $this->Member->id));
                $this->redirect(array("controller" => "Memberapplications", "action" => "view", $this->Member->Memberapplication->id));
            } else {
                $this->Member->rollback();
                $this->Session->setFlash(__("續期不成功。") . ' (' . $error . ')', 'default', array('class' => 'alert alert-danger'));
            }
        }
        $this->set('units', $this->Member->Memberapplication->Unit->find('list', array("conditions" => array($this->Member->Memberapplication->Unit->alias . ".active" => 1))));
        $this->set('membertypes', $this->Member->Membertype->find('list', array("conditions" => array($this->Member->Membertype->alias . ".active" => 1))));
    }

    public function sendresetpwdmail($id)
    {
        if (configure::read("member_username") == "email") {
            $this->autoRender = false;
            $this->Member->recursive = 0;
            $rs = $this->Member->find('first', array(
                    'conditions' => array(
                        'Member.id' => $id,
                        'Member.active' => 1
                    )
                )
            );
            if (!empty($rs)) {
                $this->Member->id = $rs['Member']['id'];
                $verifystring = md5(uniqid(rand()));
                $this->Member->id = $rs['Member']['id'];
                if ($this->Member->saveField('resetpwd_hashstring', $verifystring)) {
                    $Email = new CakeEmail('default');
                    $Email->template('sendresetpwdmail', 'membermail');
                    $Email->emailFormat('html');
                    $Email->subject("TESTING");
                    $Email->to($rs['Member']['username']);
                    $Email->helpers(array('Html'));
                    $Email->viewVars(array('hashstring' => $verifystring));
                    $Email->send();
                    echo "OK";
                }
            }
        }
    }

    /**
     * delete method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function delete($id = null)
    {
        $this->Member->id = $id;
        if (!$this->Member->exists()) {
            throw new NotFoundException(__('Invalid member'));
        }
        $this->request->allowMethod('post', 'delete');
        if ($this->Member->delete()) {
            $this->Session->setFlash(__('成功刪除'), 'default', array('class' => 'alert alert-success'));
        } else {
            $this->Session->setFlash(__('失敗，請再檢查後嘗試'), 'default', array('class' => 'alert alert-danger'));
        }
        return $this->redirect(array('action' => 'index'));
    }

    public function changeinvalid($id = null)
    {

        if (!$this->Member->exists($id)) {
            throw new NotFoundException(__('Invalid user'));
        }

        if ($this->request->is(array('post', 'put'))) {
//            Configure::write('debug',2);
            $this->Member->id = $id;
            $member = $this->Member->read();

            $member['Member']['valid'] = false;
            $member['Member']['membershipdate'] = date("Y-m-d");
            $member['Member']['last_memberapplication_id'] = 0;


            if ($this->Member->save($member)) {
                $this->Session->setFlash(__('成功退會'), 'default', array('class' => 'alert alert-success'));
            } else {
                $this->Session->setFlash(__('失敗，請再檢查後嘗試'), 'default', array('class' => 'alert alert-danger'));
            }
            return $this->redirect(array('action' => 'index'));
        }
    }

    public function changeactive()
    {
        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');
        $msg = array('result' => false);
        if ($this->request->is('post') || $this->request->is('put')) {
            $id = $this->request->data['member_id'];
            $active = $this->request->data['active'];
            if (!$this->Member->exists($id)) {
                throw new NotFoundException(__('Invalid user'));
            }
            $this->Member->id = $id;
            if ($this->Member->saveField('active', $active)) {
                $msg = array('result' => true, 'active' => $active, 'posted' => $this->request->data);
            }
        }

        echo json_encode($msg);
    }

    public function checkinfo_extend()
    {
        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');

        $result = "success";

        $options = array(
            'recursive' => -1,
            'conditions' => array(
                'Member.code' => $this->request->data['code']
            )
        );

        $member = $this->Member->find('first', $options);

        $relationship = $this->Member->find('first', array(
            'conditions' => array(
                'Member.id' => $member['Member']['id']
            ),
            'contain' => array(
                'Parentmember.Parentmember' => array(
                    'conditions' => array(
                        'Parentmember.id' => $this->request->data['mainmember_id']
                    )
                ),
                'Parentmember.Memberrelation',
                'Childmember.Childmember' => array(
                    'conditions' => array(
                        'Childmember.id' => $this->request->data['mainmember_id']
                    )
                ),
                'Childmember.Memberrelation'
            )
        ));

        foreach ($relationship['Parentmember'] as $key => $val) {
            $relationship['Parentmember'][$key]['Relatedmember'] = $val['Childmember'];
        }

        foreach ($relationship['Childmember'] as $key => $val) {
            $relationship['Childmember'][$key]['Relatedmember'] = $val['Parentmember'];
        }

        if (empty($member)) {
            $result = "找不到會員資料";
            $response = array(
                "status" => $result,
                "member" => $member,
            );
            echo json_encode($response);
            return;
        }

//        $membership_renew_days = configure::read("membership_renew_days");
//        $caltime = strtotime("+".$membership_renew_days.'days');
//        $beforetimesp = strtotime(date("Y-m-d",$caltime));
//        if($beforetimesp < strtotime($member['Member']['membershipdate'])){
//            $result = __('會籍到期日是'.$member['Member']['membershipdate']."。還未能續期。");
//        }

//        if (!($member['Member']['valid'])) {
//            $result = __('無效會員');
//        }

        $response = array(
            "status" => $result,
            "member" => $member,
            "relationship" => array_merge($relationship['Parentmember'], $relationship['Childmember'])
        );
        echo json_encode($response);
    }

    public function ajax_matching()
    {
        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');
        $result = false;
        $errormsg = "";

        if ($this->request->is('post') || $this->request->is('put')) {

            $from_age = trim($this->request->data['Member']['from_age']);
            $to_age = trim($this->request->data['Member']['to_age']);
            $idle_period = trim($this->request->data['Member']['idle_period']);
            $membertypes = $this->request->data['Member']['membertype'];
            $eventproposaltargets = $this->request->data['Member']['eventproposaltarget'];


            $this->Member->virtualFields = array(
                'age' => '(PERIOD_DIFF( DATE_FORMAT(CURDATE(), "%Y%m") , DATE_FORMAT(' . $this->Member->alias . '.dob, "%Y%m") )) DIV 12',
            );

            //If month_ago less idle period, activity will be retrieve, which means during the desired idle period, the member participated in at least one activity
            $this->Member->Activity->virtualFields = array(
                'month_ago' => '(PERIOD_DIFF( DATE_FORMAT(CURDATE(), "%Y%m") , DATE_FORMAT(' . $this->Member->Activity->alias . '.enddate, "%Y%m") )) MOD 12',
            );

            if (empty($from_age) && empty($to_age) && empty($idle_period) && empty($membertypes) && empty($eventproposaltargets)) {
                $errormsg = "必須至少填寫其中一個條件";
            } else {
                $condition_member = array();
                $condition_activity = array();
                $condition_eventproposaltarget = array();


                //conditions for Eventproposaltarget
                if (!empty($eventproposaltargets)) {
                    foreach ($eventproposaltargets as $eventproposaltarget) {
                        $condition_eventproposaltarget['OR'][][$this->Member->Eventproposaltarget->alias . '.id'] = $eventproposaltarget;
                    }
                }

                //conditions for Member
                if (!empty($membertypes)) {
                    foreach ($membertypes as $membertype) {
                        $condition_member['AND']['OR'][][$this->Member->alias . '.membertype_id'] = $membertype;
                    }
                }

                $condition_member['AND'][$this->Member->alias . '.active'] = true;
                $condition_member['AND'][$this->Member->alias . '.valid'] = true;

                if (!empty($from_age)) {
                    $condition_member['AND'][$this->Member->alias . ".age >="] = $from_age;
                }
                if (!empty($to_age)) {
                    $condition_member['AND'][$this->Member->alias . ".age <="] = $to_age;
                }

                //conditions for Activity
                if (!empty($idle_period)) {
                    $condition_activity['AND']['((PERIOD_DIFF( DATE_FORMAT(CURDATE(), "%Y%m") , DATE_FORMAT(Activity.enddate, "%Y%m") )) MOD 12) <='] = $idle_period;
                }

                if (!(empty($condition_member) && empty($condition_activity) && empty($condition_eventproposaltarget))) {
                    $this->Member->Behaviors->load('Containable');
                    $serachresult = $this->Member->find("all", array(
                        "conditions" => $condition_member,
                        "contain" => array(
                            "Eventproposaltarget" => array(
                                "conditions" => $condition_eventproposaltarget
                            ),
                            "MemberCustomField.Memberinputfield",
                            "Activity" => array(
                                "conditions" => $condition_activity,
                                "fields" => array("month_ago"),
                            )
                        ),

                    ));

                    if (!empty($serachresult)) {
                        foreach ($serachresult as $key => $val) {
                            $serachresult[$key]['Member']['hkid'] = substr($serachresult[$key]['Member']['hkid'], 0, -4) . 'xxxx';
                            $serachresult[$key]['MemberCustomField'] = Set::combine($serachresult[$key]['MemberCustomField'], '{n}.Memberinputfield.id', "{n}");
                            if (!empty($idle_period)) {
                                if ($serachresult[$key]['Activity'] != null) {
                                    continue;
                                }
                            }
                            if (!empty($eventproposaltargets)) {
                                if ($serachresult[$key]['Eventproposaltarget'] == null) {
                                    continue;
                                }
                            }

                            $result[] = $serachresult[$key];
                        }
                    }
                }

                if (empty($result)) {
                    $errormsg = "沒有記錄";
                }
            }

            echo json_encode(
                array(
                    "result" => $result,
                    "errormsg" => $errormsg
                )
            );
        }
    }

//需要整張FORM 連token post過來
    public function ajax_checkinfo()
    {
        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');
        $result = false;
        $errormsg = "";

        if ($this->request->is('post') || $this->request->is('put')) {
            $membercard = trim($this->request->data['Member']['membercard']);
            $code = trim($this->request->data['Member']['code']);
            $c_name = trim($this->request->data['Member']['c_name']);
            $e_name = trim($this->request->data['Member']['e_name']);
            $phone_main = trim($this->request->data['Member']['phone_main']);
            $identity = trim(strtoupper($this->request->data['Member']['identity']));
            if (!empty($identity)) {
                $identityhash = $this->Member->datahash($identity);
            }


            if (empty($c_name) && empty($e_name) && empty($phone_main) && empty($identityhash) && empty($code) && empty($membercard)) {
                $errormsg = "必須至少填寫其中一個條件";
            } else {
                $conditions = array();
                if (!empty($membercard)) {
                    $conditions['AND'][$this->Member->alias . ".membercard"] = $membercard;
                }
                if (!empty($c_name)) {
                    $conditions['AND'][$this->Member->alias . ".c_name LIKE"] = "%" . $c_name . "%";
                }
                if (!empty($e_name)) {
                    $conditions['AND'][$this->Member->alias . ".e_name LIKE"] = "%" . $e_name . "%";
                }
                if (!empty($identityhash)) {
                    $conditions['OR'][$this->Member->alias . ".identityhash"] = $identityhash;
                }
                if (!empty($code)) {
                    $conditions['AND'][$this->Member->alias . ".code"] = $code;
                }
                if (!empty($conditions)) {
                    $this->Member->recursive = -1;
                    $serachresult = $this->Member->find("all", array(
                        "conditions" => $conditions,
                        'fields' => array(
                            "id", "code", "e_name", "c_name", "identity"
                        ),
                        "contain" => array(
                            "MemberCustomField"
                        )
                    ));

                    if (!empty($serachresult)) {
                        foreach ($serachresult as $key => $val) {
//                                $serachresult[$key]['Member']['hkid'] = substr($serachresult[$key]['Member']['hkid'], 0, -4) . 'xxxx';
                            $result[$serachresult[$key]['Member']['id']]['Member'] = $serachresult[$key]['Member'];
                        }
                    }
                }
                if (!empty($phone_main)) {
                    $conditions['AND'] = array(
                        'MemberCustomField.memberinputfield_id' => configure::read("Memberinputfield.phone_main_index"),
                        'MemberCustomField.value' => $phone_main
                    );

                    $serachresult = $this->Member->MemberCustomField->find("all", array(
                        "conditions" => array(
                            $conditions
                        ),
                        "fields" => array(
                            "DISTINCT Member.id", "Member.code", "Member.e_name", "Member.c_name", "Member.identity"
                        )
                    ));
                    if (!empty($serachresult)) {
                        foreach ($serachresult as $key => $val) {
//                                $serachresult[$key]['Member']['hkid'] = substr($serachresult[$key]['Member']['hkid'], 0, -4) . 'xxxx';
                            $result[$serachresult[$key]['Member']['id']]['Member'] = $serachresult[$key]['Member'];
                        }
                    }
                }
                if (empty($result)) {
                    $errormsg = "沒有記錄";
                }
            }

            echo json_encode(
                array(
                    "result" => $result,
                    "errormsg" => $errormsg
                )
            );
        }
    }

    public function ajax_checkidentity(){
        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');
        if($this->request->is('post') || $this->request->is('put')) {
            $hkid = trim(strtoupper($this->request->data['hkid']));

            if (!preg_match('/^[a-zA-Z]{1,2}\d{6}\([0-9a-zAZ-Z]\)$/', $hkid))
            {
                echo json_encode(false);;
            }
            else{
                App::import('Vendor', 'hkid');
                $obj_hkid = new HKID();
                $obj_hkid->set($hkid);

                if(!$obj_hkid->validate()){
                    echo json_encode(false);;
                }else{
                    echo json_encode(true);
                }
            }

        }
    }

    public function beforeFilter()
    {
        if ($this->request['action'] == 'sendconfirmmail' || $this->request['action'] == 'sendresetpwdmail') {
            $this->allowtoken();
            $this->Security->unlockedActions[] = 'sendresetpwdmail';
            $this->Security->unlockedActions[] = 'sendconfirmmail';
        }
        if ($this->request['action'] == 'ajax_checkinfo') {
            $this->Security->csrfUseOnce = false;
        }
        if ($this->request['action'] == 'ajax_matching') {
            $this->Security->csrfUseOnce = false;
        }
        if ($this->request['action'] == 'newmemberfamily') {
            $this->Security->unlockedFields = array('ExistingMember');
        }
        if ($this->request['action'] == 'extendindividual') {
            $this->Security->unlockedFields = array('Member.Member' ,"Member.membershipdate");
        }
        if ($this->request['action'] == 'extendfamily') {
            $this->Security->unlockedFields = array('Member.Member' ,"Member.membershipdate" ,"Parentmember", "Membership");
        }
        if ($this->request['action'] == 'edit') {
            $this->Security->unlockedFields = array('Parentmember');
        }

        $this->Security->unlockedActions[] = 'checkinfo_extend';
        $this->Security->unlockedActions[] = 'ajax_checkidentity';
        $this->Security->unlockedActions[] = 'changeactive';
        $this->Security->unlockedActions[] = 'ajax_checkunique';
        parent::beforeFilter();
    }

}
