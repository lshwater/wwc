<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');
/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {


	public $candelete = false;
    public $systemversion = "1.0";
	
	public $components = array(
//			'DebugKit.Toolbar',
			'Acl',
			'Auth' => array(
                'authenticate' => array(
                    'Form' => array(
                        'passwordHasher' => array(
                                'className' => 'Simple',
                                'hashType' => 'sha256'
                        )
                    )
                ),
                'authorize' => array(
                    'Actions' => array(
                        'actionPath' => 'controllers'
                    ),
                    'Controller',
                ),
			),
			'Session',
			'Security',
            'RequestHandler'
	);

	public function beforeFilter() {

        if(preg_match('/(?i)msie [1-8]/',$_SERVER['HTTP_USER_AGENT']))
        {
            // if IE<=8
            $this->Session->setFlash(__('本網站只支援 Internet Explorer 9 或以上版本，或建議使用其他瀏覽器 （如 Chrome / Firefox）。'), 'default', array('class'=>'alert alert-danger'));
        }
        if($this->request->params['named']['ajax']){
            $this->layout = "ajax";
            $this->set("isajax", 1);
        }else{
            $this->set("isajax", 0);
        }
        if($this->request->params['named']['withoutmenu']){
            $this->layout = "withoutmenu";
            $this->set("withoutmenu", 1);
        }else{
            $this->set("withoutmenu", 0);
        }
        Configure::write('Config.language', 'zh_tw');
        $this->Session->write('Config.language', 'zh_tw');
        setlocale(LC_TIME, "zh_TW.utf8");
		$this->Security->blackHoleCallback = 'blackhole';
		
		if ($this->Auth->loggedIn()) {
			$this->loadModel('User');
            $this->loadModel('Menu');

            //get getpendingcount
            $pendingcountofeventproposal = $this->User->getpendingcountofeventproposal();

			$this->User->get_groups();
			if(!$this->User->checkactive()){
				$this->Session->destroy();
				$this->Session->setFlash('You account is inactive!');
				$this->redirect($this->Auth->logout());
			}

            //gol variable
            $this->set('auth',$this->Auth->user());
            $this->set("groupsusers",$this->Session->read('Auth.groupsusers'));
            $this->set('isadmin',$this->Session->read('Auth.isadmin'));
            $this->set('mainmenus',$this->Menu->getmenu());
            $this->loadModel("Notification");
            $this->set('_notices', $this->Notification->getunreadnotices());
            $this->loadModel("Message");
            $this->set('_messages', $this->Message->getunreadmsgs());
            $this->set("pendingcountofeventproposal", $pendingcountofeventproposal);

            //Save Log
            if(Configure::read("modulus.Actionlog")){
                $this->loadModel('Actionlog');
                $this->Actionlog->addlog($this->request);
            }

            //Cutoffdate
            if(Configure::read("modulus.Cutoffdate")){
                $this->loadModel("Cutoffdate");
                $cutoffdate = $this->Cutoffdate->getlastdate();
                $this->set('_cutoffdate', $cutoffdate);
                Configure::write('cutoffdate', $cutoffdate);
            }
		}
		$this->Auth->allow('login','logout', 'home');
	
		$this->Auth->loginAction = array('controller' => 'pages', 'action' => 'display', 'home');
		$this->Auth->logoutRedirect = array('controller' => 'pages', 'action' => 'display', 'home');
		$this->Auth->loginRedirect = array('controller' => 'users', 'action' => 'dashboard');
		$this->Auth->unauthorizedRedirect = array('controller' => 'users', 'action' => 'dashboard');
		$this->Auth->authError = __('你必須登入。');
	}

    public function allowtoken(){
        $this->Auth->authenticate = array(
            'Authenticate.Token' => array(
                'parameter' => '_token',
                'header' => 'token',
                'userModel' => 'Users',
                'fields' => array(
                    'token' => 'token',
                ),
                'continue' => true
            )
        );

    }

    public function ajax_checkunique(){

        $this->autoRender = false;
        $this->RequestHandler->respondAs('json');
        if ($this->request->is('post') || $this->request->is('put')) {
            $controller = $this->request['controller'];
            $this->loadModel($controller);
            $field = $this->request->data['field'];
            $value = $this->request->data['value'];
            $recordid = $this->request->data['recordid'];

            if ($field == 'identity') {
                $field = "identityhash";
                $value = $this->{$controller}->datahash(strtoupper($value));
            }

            if($this->{$controller}->find('count', array(
                    'conditions'=>array(
                        $this->{$controller}->alias.'.'.$field=>$value,
                        $this->{$controller}->alias.".id != "=>$recordid
                    )
                )) == 0){
                echo json_encode(true);
            }else{
                echo json_encode(__('Already Token'));
            }
        }
    }

	public function blackhole($type) {
		// handle errors.
//        Configure::write('debug', 2);
		print_r($type);
		throw new NotFoundException(__('保安問題，請重新嘗試！'));

	}

    function isAuthorized($user) {
        //ACL mamager update need to uncomemnt
//        return $this->Auth->loggedIn();
         return false;

    }
}
