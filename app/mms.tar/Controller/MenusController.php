<?php
App::uses('AppController', 'Controller');

class MenusController extends AppController {

}