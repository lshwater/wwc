<?php
App::uses('AppController', 'Controller');

class ApprovalrecordsController extends AppController {

    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator');

    /**
     * index method
     *
     * @return void
        */


    public function beforeFilter()
    {
        parent::beforeFilter();
    }

}
