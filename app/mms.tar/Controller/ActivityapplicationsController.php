<?php
App::uses('AppController', 'Controller');


class ActivityapplicationsController extends AppController
{
    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator', 'Search.Prg', 'DataTable');

    public function histories(){
        $activityapplications = $this->Activityapplication->find("all");
        $this->set("activityapplications", $activityapplications);
    }

    public function ajax_histories(){
//        Configure::write('debug',2);
        $this->autoRender = false;
        $this->Activityapplication->Behaviors->load('Containable');
        $this->paginate = array(
            'fields' => array(
                'Activityapplication.id',
                'Activityapplication.code',
                "Activityapplication.created",
                "Activityapplication.payment_code",
            ),
            'order' => 'Activityapplication.code DESC',

        );
        $this->DataTable->mDataProp = true;
        echo json_encode($this->DataTable->getResponse());
    }

    public function receipt($id = null){
        if(!$this->Activityapplication->exists($id)){
            throw new NotFoundException(__('Invalid'));
        }
        $this->layout = "withoutmenu";

        $this->Activityapplication->Behaviors->load('Containable');
        $activityapplication = $this->Activityapplication->find("first", array(
           "conditions"=>array(
               $this->Activityapplication->alias.".id"=>$id
           ),
           "contain"=>array(
               "Activityapplicant",
               "Activityapplicant.Member.Membertype",
               "Activity",
               "User"
           )
        ));
        $this->set("activityapplication", $activityapplication);
    }

    public function ajax_updateremarks(){
        $this->autoRender = false;
        $remarks = $this->request->data['value'];
        $pk = $this->request->data['pk'];
        if(!empty($pk)){
            $this->Activityapplication->id = $pk;
            $this->Activityapplication->saveField(
                "remarks",
                $remarks
            );
            echo "OK";
        }
    }

    public function beforeFilter()
    {
        $this->Security->unlockedActions[] = "ajax_histories";
        $this->Security->unlockedActions[] = "ajax_updateremarks";
        parent::beforeFilter();
    }

}
